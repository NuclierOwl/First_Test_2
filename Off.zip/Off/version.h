#pragma once

#define PROJECT_VERSION_PATCH 2
