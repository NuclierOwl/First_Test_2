#include <iostream>
using namespace std;



int mein() {
    setlocale(LC_ALL, "RU");
    double a= 100;
return 100;

}