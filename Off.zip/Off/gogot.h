
#pragma once

int version();